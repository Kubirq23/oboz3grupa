please contact me for commercial use.
this font free for personal project, non-profit and charity use.

if you make money from using my fonts, please purchase a commercial license at here.
https://www.creativefabrica.com/product/pixelon/ref/236724/

for other license, contact me via email -> studioaktype@gmail.com
and follow my instragram for update -> @studioaktype

if you want DONATE click here https://www.paypal.com/paypalme/d24nie
i really appreciate your donations.

thank you ;)